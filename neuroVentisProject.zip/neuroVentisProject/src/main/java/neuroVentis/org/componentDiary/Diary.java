package neuroVentis.org.componentDiary;

import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Diary {

    @FindBy(xpath ="//i[@class=\"icon-logs\"]")
    WebElement diaryButton;

    @FindBy(xpath ="//div[@class=\"text actionable ng-scope\"][1]")
    WebElement editSeizure;


    //Constructor
    public Diary () {

        //Initialising the Elements to the driver
        PageFactory.initElements(Global_Utilities.webDriver, this);
    }

    public void EditSeizureStep1() throws InterruptedException {
        /*This method edits the Seizure*/
         Thread.sleep(1000);
        diaryButton.click();

        editSeizure.click();
        System.out.println(editSeizure.getText());

    }


    }
