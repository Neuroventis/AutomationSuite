package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

//Bhargav
import org.openqa.selenium.JavascriptExecutor;

public class HomePage extends BaseClass {


    @FindBy(xpath ="//div[@class=\"icon ng-scope\"]/i" )
    WebElement addButton;
    @FindBy(xpath ="//div[@class=\"items-wrapper\"][1]/div[1]")
    WebElement seizureButton;
    //div[@class="colored-type sub ng-scope"]

    //Constructor
    public HomePage () {

        //Initialising the Elements to the driver
        PageFactory.initElements(Global_Utilities.webDriver, this);
    }

    public void addFunctionality() throws InterruptedException {
        JavascriptExecutor executor = (JavascriptExecutor) Global_Utilities.webDriver;
        executor.executeScript("arguments[0].scrollIntoView(true);", addButton);
        addButton.click();
        Thread.sleep(1000);
        JavascriptExecutor executors = (JavascriptExecutor) Global_Utilities.webDriver;
        executors .executeScript("arguments[0].scrollIntoView(true);", seizureButton);
        seizureButton.click();

        }
}
