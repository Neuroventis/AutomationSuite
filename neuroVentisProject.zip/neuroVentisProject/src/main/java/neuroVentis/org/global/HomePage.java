package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

public class HomePage extends BaseClass {


    @FindBy(xpath ="//div[@class=\"icon ng-scope\"]/i" )
    WebElement addButton;
    @FindBy(xpath ="//div[@class=\"items-wrapper\"][1]/div[1]")
    WebElement seizureButton;
    @FindBy(xpath ="//i[@class=\"icon-home\"]")
    WebElement homeNavigationButton;
    @FindBy(xpath ="//div[@class=\"legend\"]/div[1]")
    WebElement homeSeizureDisplayText;

    String homePageTitleText="//div[contains(.,'Home')]";



    //Constructor
    public HomePage () {

        //Initialising the Elements to the driver
        PageFactory.initElements(Global_Utilities.webDriver, this);
    }

    public void addFunctionality()  {
        /*This method clicks on Add and then clicks on Seizure*/


        JavascriptExecutor addExecutor = (JavascriptExecutor) Global_Utilities.webDriver;
        addExecutor.executeScript("arguments[0].scrollIntoView(true);", addButton);
        addExecutor.executeScript("arguments[0].click();", addButton);
        //addButton.click();

        JavascriptExecutor seizureExecutor = (JavascriptExecutor) Global_Utilities.webDriver;
        seizureExecutor .executeScript("arguments[0].scrollIntoView(true);", seizureButton);
        seizureButton.click();

        }

    public void addSeizureAssert(){

        System.out.println(homeSeizureDisplayText.getText());




    }

    public void navigateHome(){

        homeNavigationButton.click();

    }

    public void homePageAssert(){

        boolean  flag2 =  GenericMethods.visibleStatusOfWebElement(homePageTitleText);
        Assert.assertEquals(flag2,true);
    }



}
