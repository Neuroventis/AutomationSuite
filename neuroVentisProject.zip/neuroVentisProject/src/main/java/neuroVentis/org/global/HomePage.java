package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.JavascriptExecutor;

public class HomePage extends BaseClass {


    @FindBy(xpath ="//div[@class=\"icon ng-scope\"]/i" )
    WebElement addButton;
    @FindBy(xpath ="//div[@class=\"items-wrapper\"][1]/div[1]")
    WebElement seizureButton;

    String homePageTitleText="//div[contains(.,'Home')]";

    //div[@class="colored-type sub ng-scope"]

    //Constructor
    public HomePage () {

        //Initialising the Elements to the driver
        PageFactory.initElements(Global_Utilities.webDriver, this);
    }

    public void addFunctionality()  {
        /*This method clicks on Add and then clicks on Seizure*/


        JavascriptExecutor addExecutor = (JavascriptExecutor) Global_Utilities.webDriver;
        addExecutor.executeScript("arguments[0].scrollIntoView(true);", addButton);
        addExecutor.executeScript("arguments[0].click();", addButton);
        //addButton.click();

        JavascriptExecutor seizureExecutor = (JavascriptExecutor) Global_Utilities.webDriver;
        seizureExecutor .executeScript("arguments[0].scrollIntoView(true);", seizureButton);
        seizureButton.click();

        }
}
