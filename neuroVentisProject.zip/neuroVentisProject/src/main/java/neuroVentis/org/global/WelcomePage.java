package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class WelcomePage extends BaseClass {

    @FindBy(xpath ="//div[@class='nb-swipe-selectors ball']/div[3]")
    WebElement urlOpenPageDownRadioButtonLetsgo;

    @FindBy(xpath ="//div[@class=\"content ng-scope header-link-color\"]/div[@class=\"txt ng-scope\"]" )
    WebElement openPageLetsGoClick;

    @FindBy(xpath = "//div[@class=\"log btn-helpilepsy\"]")
    WebElement existingAccount;

    String logInPageText ="//span[contains(.,'Log in')]";
    String helpilepsyText ="//h1[text()='Helpilepsy']";

    //Constructor
    public WelcomePage() {

        //Initialising the Elements to the driver
        PageFactory.initElements(Global_Utilities.webDriver, this);
    }

    public void ClickOnLetsGo() throws InterruptedException {
     /*This method clicks on the radio button which is towards down and then on let's go button,
        once the application is opened.*/

        urlOpenPageDownRadioButtonLetsgo.click();
        openPageLetsGoClick.click();


    }

    public void selectingExistingAccount() throws InterruptedException {

        /*This method validates the logo(Helpilepsy)of the application and then clicks on
        existing account to login.*/

        ClickOnLetsGo();
        boolean  flag1 =  GenericMethods.visibleStatusOfWebElement(helpilepsyText);
        Assert.assertEquals(flag1,true);
        existingAccount.click();
        boolean  flag2 =  GenericMethods.visibleStatusOfWebElement(logInPageText);
        Assert.assertEquals(flag2,true);

    }

}
