package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage extends HomePage {

    @FindBy(name ="email" )
    WebElement email;
    @FindBy(name ="password" )
    WebElement password;
    @FindBy(xpath ="//button[text()=\"Log in\"]" )
    WebElement loginButton;


    //Constructor
    public LoginPage () {

        //Initialising the Elements to the driver
        PageFactory.initElements(Global_Utilities.webDriver, this);
    }

    public void enterCredentials(String username, String password) {
       //email
        email.clear();
        email.sendKeys(username);

        //password
        this.password.clear();
        this.password.sendKeys(password);

        //login
        loginButton.click();

        //validate
        boolean  flag2 =  GenericMethods.visibleStatusOfWebElement(homePageTitleText);
        Assert.assertEquals(flag2,true);


    }


    
}
