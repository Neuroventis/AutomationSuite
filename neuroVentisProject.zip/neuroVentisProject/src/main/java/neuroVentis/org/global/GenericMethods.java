package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

public class GenericMethods extends BaseClass {


    public static void assignTestCaseId(int test_id){

        Global_Utilities.TestCaseId = test_id;
    }

    public  static void validAccountLoginAndNavigateToHome() throws InterruptedException {

        WelcomePage welcomePageObj= new WelcomePage();
        welcomePageObj.selectingExistingAccount();
        LoginPage loginPageObj = new LoginPage();
        loginPageObj.enterCredentials(Global_Utilities.properties.getProperty("username"), Global_Utilities.properties.getProperty("password"));

    }

    public  static boolean  visibleStatusOfWebElement(String e) {
        try {
            Global_Utilities.webDriver.findElement(By.xpath(e)).isDisplayed();
            return true;
        } catch (NoSuchElementException nse) {
            return false;

        }
    }


}
