package neuroVentis.org.componentSeizures;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddSeizureFunctionality extends BaseClass {

    @FindBy(xpath ="//div[@class=\"inline-group type\"][1]/div[2]")
    WebElement clickSeizureTypeDropDown;

    @FindBy(xpath ="//div[@class=\"inside-content\"][1]/div[2]")
    WebElement selectSeizureType;

    @FindBy(xpath ="//div[@class=\"custom-radio\"][2]/input[@id=\"felt_no\"]")
    WebElement seizureTypeRadioButton;

    @FindBy(xpath ="//button[@class=\"btn-helpilepsy green\"]")
    WebElement saveSeizureButton;

    @FindBy(xpath ="//div[@data-ng-show=\"okModal\"]//div[@class=\"nb-modal-wrapper\"]/div[@class=\"content\"]/div[@class=\"actions\"]/button[@class=\"btn-dark ng-scope\"]")
    WebElement okButton;


    //Constructor
    public AddSeizureFunctionality () {

        //Initialising the Elements to the driver
        PageFactory.initElements(Global_Utilities.webDriver, this);
    }


    public void seizureTypeDropdown() {

        JavascriptExecutor seizureTypeDropDown = (JavascriptExecutor) Global_Utilities.webDriver;
        seizureTypeDropDown.executeScript("arguments[0].scrollIntoView(true);", clickSeizureTypeDropDown);
        clickSeizureTypeDropDown.click();

    }

    public void seizuresType(){

            JavascriptExecutor seizureType = (JavascriptExecutor) Global_Utilities.webDriver;
            seizureType .executeScript("arguments[0].scrollIntoView(true);", selectSeizureType);
            selectSeizureType.click();
    }

     public void seizuresTypeRadio() {

         JavascriptExecutor SeizureTypeRadio = (JavascriptExecutor) Global_Utilities.webDriver;
         SeizureTypeRadio.executeScript("arguments[0].scrollIntoView(true);", seizureTypeRadioButton);
         SeizureTypeRadio.executeScript("arguments[0].click();", seizureTypeRadioButton);
     }

    public void seizureSave() throws InterruptedException {
        JavascriptExecutor saveSeizure = (JavascriptExecutor) Global_Utilities.webDriver;
        saveSeizure.executeScript("arguments[0].scrollIntoView(true);", saveSeizureButton);
        saveSeizureButton.click();
        //Thread.sleep(1000);
        okButton.click();

    }

    public void newSeizure() throws InterruptedException {
        seizureTypeDropdown();
        seizuresType();
        seizuresTypeRadio();
        seizureSave();

    }



}
