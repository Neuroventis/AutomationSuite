package neuroVentis.org.componentSeizures;

import neuroVentis.org.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EditSeizureFunctionality extends AddSeizureFunctionality {


    @FindBy(xpath ="//i[@class=\"icon-logs\"]")
    WebElement diaryButton;

    @FindBy(xpath ="//div[@class=\"text actionable ng-scope\"][1]")
    WebElement editSeizure;

    @FindBy(xpath ="//div[@class=\"inside-content\"][1]/div[4]")
    WebElement editSelectSeizureType;

    @FindBy(xpath ="//div[@class=\"elem right-elem\"]")
    WebElement editSave;


    public void EditSeizure() throws InterruptedException {


        diaryButton.click();

        Thread.sleep(3000);
        editSeizure.click();

        Thread.sleep(1000);
        clickSeizureTypeDropDown.click();
        Thread.sleep(1000);
        editSelectSeizureType.click();
        editSave.click();

        //WebElement element = Global_Utilities.webDriver.findElement(By.xpath("//div[@data-ng-show=\"okModal\"]//div[@class=\"nb-modal-wrapper\"]/div[@class=\"content\"]/div[@class=\"actions\"]/button[@class=\"btn-dark ng-scope\"]"));
        //String text = element.getText();
        //System.out.println(text);
    }

}
