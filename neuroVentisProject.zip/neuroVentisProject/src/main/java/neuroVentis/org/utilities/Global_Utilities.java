package neuroVentis.org.utilities;

import neuroVentis.org.base.BaseClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Properties;

public class Global_Utilities extends BaseClass {

    // Variables

    public static Properties properties;
    public static WebDriver webDriver;
    public static int TestCaseId;
    public static WebDriverWait webDriverWait;




}
