package neuroVentis.org.utilities.listener_Utilities;

import neuroVentis.org.utilities.Global_Utilities;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;

public class ITListener implements ITestListener {


    //Invoked each time before a test will be invoked.
    public void onTestStart(ITestResult iTestResult) {
        System.out.println("Run before each test"+iTestResult.getName());
    }

    //Invoked after all the tests have run and all their Configuration methods have been called.
    public void onFinish(ITestContext iTestContext) {
        System.out.println("Run after all the tests"+ iTestContext.getName());

    }
    //Invoked each time a test succeeds.
    public void onTestSuccess(ITestResult iTestResult) {
        System.out.println("Your test passed and runs when test passed"+ iTestResult.getName());
    }

    //Invoked each time a test fails.
      public void onTestFailure(ITestResult iTestResult) {
        // System.out.println("Your test failed and runs when test passed"+ iTestResult.getName());

        try {
            TakesScreenshot tc = (TakesScreenshot) Global_Utilities.webDriver;
            File f = tc.getScreenshotAs(OutputType.FILE);
            String buildFilePath = "src\\main\\java\\neuroVentis\\org\\reports\\" + Global_Utilities.TestCaseId + ".png";
            FileUtils.copyFile(f, new File(buildFilePath));
        }catch (IOException e){

        }

    }

    //Invoked after the test class is instantiated and before any configuration method is called.
    public void onStart(ITestContext iTestContext) {
        System.out.println("Run before all the tests"+ iTestContext.getName());

    }

    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    public void onTestSkipped(ITestResult iTestResult) {

    }
}