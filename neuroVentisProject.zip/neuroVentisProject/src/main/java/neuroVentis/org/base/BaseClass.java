package neuroVentis.org.base;

import io.github.bonigarcia.wdm.WebDriverManager;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class BaseClass {

    public void loadProperties() throws IOException {
        FileInputStream fileInputStream = new FileInputStream("C:\\neuroVentisProject\\src\\config.properties");
        Global_Utilities.properties= new Properties();
        Global_Utilities.properties.load(fileInputStream);

    }

    /* This method will setup the driver
        Launch browser & maximize the browser
        Navigate to the NeuroVentis welcome page
      */
    public void OpenBrowserAndNavigateToNeuroVentis(String browserName){

        if(browserName.equals("chrome")){
            WebDriverManager.chromedriver().setup();
            Global_Utilities.webDriver= new ChromeDriver();
        } else if(browserName.equals("Firefox") || browserName.equals("FF")){
            WebDriverManager.firefoxdriver().setup();
            Global_Utilities.webDriver= new FirefoxDriver();
        }
        Global_Utilities.webDriver.manage().window().maximize();
        Global_Utilities.webDriver.manage().deleteAllCookies();
        Global_Utilities.webDriver.get(Global_Utilities.properties.getProperty("url"));
        Global_Utilities.webDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Global_Utilities.webDriverWait=new WebDriverWait(Global_Utilities.webDriver, 20);



    }

}
