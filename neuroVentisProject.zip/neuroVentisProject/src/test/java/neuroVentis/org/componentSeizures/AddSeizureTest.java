package neuroVentis.org.componentSeizures;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.global.GenericMethods;
import neuroVentis.org.global.HomePage;
import neuroVentis.org.utilities.Global_Utilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.io.IOException;

@Listeners(neuroVentis.org.utilities.listener_Utilities.ITListener.class)

public class AddSeizureTest extends BaseClass {

    HomePage homePageObj;
    AddSeizureFunctionality addSeizureFunctionalityObj;

    @BeforeMethod(alwaysRun = true)
    void setUp() throws IOException {
        /*This method loads the url and login details from property file*/

        loadProperties();
        OpenBrowserAndNavigateToNeuroVentis(Global_Utilities.properties.getProperty("browser"));
        GenericMethods.validAccountLoginAndNavigateToHome();
        homePageObj= new HomePage();

    }

    @Test
    void validateAddSeizure()  {
        /*This method validates the adding of new seizure*/

        GenericMethods.assignTestCaseId(4);

        homePageObj.addFunctionality();
        addSeizureFunctionalityObj= new AddSeizureFunctionality();
        addSeizureFunctionalityObj.newSeizure();
        homePageObj.homePageAssert();
        homePageObj.addSeizureAssert();

    }


    @AfterMethod(alwaysRun = true)
    void teardown()
    {
        Global_Utilities.webDriver.close();
    }



}
