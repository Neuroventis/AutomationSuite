package neuroVentis.org.componentSeizures;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.componentDiary.Diary;
import neuroVentis.org.global.GenericMethods;
import neuroVentis.org.global.HomePage;
import neuroVentis.org.utilities.Global_Utilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.io.IOException;

@Listeners(neuroVentis.org.utilities.listener_Utilities.ITListener.class)

public class EditSeizureTest extends BaseClass {


    HomePage homePageObj;
    AddSeizureFunctionality addSeizureFunctionalityObj;
    Diary diaryObj;

    @BeforeMethod(alwaysRun = true)
    void setUp() throws IOException {
        /*This method loads the url and login details from property file*/

        loadProperties();
        OpenBrowserAndNavigateToNeuroVentis(Global_Utilities.properties.getProperty("browser"));
        GenericMethods.validAccountLoginAndNavigateToHome();
        homePageObj= new HomePage();


    }

    @Test
    void editSeizure() throws InterruptedException {

        /*This method edits the Seizure going from Diary, editing the first one. */
        GenericMethods.assignTestCaseId(5);
        diaryObj=new Diary();
        diaryObj.EditSeizureStep1();
        addSeizureFunctionalityObj=new AddSeizureFunctionality();
        addSeizureFunctionalityObj.EditSeizureStep2();
        homePageObj.navigateHome();
        homePageObj.homePageAssert();
        homePageObj.addSeizureAssert();
    }

    @AfterMethod(alwaysRun = true)
    void teardown()
    {
        Global_Utilities.webDriver.close();
    }



}
