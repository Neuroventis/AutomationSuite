package neuroVentis.org.componentSeizures;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.global.HomePage;
import neuroVentis.org.global.LoginPage;
import neuroVentis.org.global.WelcomePage;
import neuroVentis.org.utilities.Global_Utilities;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class EditSeizureTest extends BaseClass {

    WelcomePage welcomePageObj;
    LoginPage loginPageObj;
    HomePage homePageObj;
    AddSeizureFunctionality addSeizureFunctionalityObj;
    EditSeizureFunctionality editSeizureFunctionalityObj;

    @BeforeMethod(alwaysRun = true)
    void setUp() throws IOException, InterruptedException {
        loadProperties();
        OpenBrowserAndNavigateToNeuroVentis(Global_Utilities.properties.getProperty("browser"));
        welcomePageObj= new WelcomePage();
        loginPageObj = new LoginPage();
        homePageObj= new HomePage();

    }

    @Test
    void editSeizure() throws InterruptedException {
        welcomePageObj.selectingExistingAccount();
        Thread.sleep(1000);
        loginPageObj.enterCredentials(Global_Utilities.properties.getProperty("username"),Global_Utilities.properties.getProperty("password"));
        Thread.sleep(1000);
        editSeizureFunctionalityObj= new EditSeizureFunctionality();
        editSeizureFunctionalityObj.EditSeizure();

    }




}
