package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.By;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class LogInPageTest extends BaseClass {

    //WelcomePage welcomePageObj;
    //LoginPage loginPageObj;

    @BeforeMethod(alwaysRun = true)
    void setUp() throws IOException, InterruptedException {
        loadProperties();
        OpenBrowserAndNavigateToNeuroVentis(Global_Utilities.properties.getProperty("browser"));
        //welcomePageObj= new WelcomePage();
        //welcomePageObj.selectingExistingAccount();
        //Thread.sleep(1000);
    }

    @Test
    void enterValidUserNameAndPassword() throws IOException, InterruptedException {

        //loginPageObj = new LoginPage();
        GenericMethods.assignTestCaseId(2);
        GenericMethods.validAccountLoginAndNavigateToHome();
        //loginPageObj.enterCredentials(Global_Utilities.properties.getProperty("username"),Global_Utilities.properties.getProperty("password"));
        //Thread.sleep(10000);

    }

}
