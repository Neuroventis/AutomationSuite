package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.IOException;

@Listeners(neuroVentis.org.utilities.listener_Utilities.ITListener.class)

public class LogInPageTest extends BaseClass {



    @BeforeMethod(alwaysRun = true)
    void setUp() throws IOException {
        /*This method loads the url and login details from property file*/

        loadProperties();
        OpenBrowserAndNavigateToNeuroVentis(Global_Utilities.properties.getProperty("browser"));

    }

    @Test
    void enterValidUserNameAndPassword() throws IOException, InterruptedException {
        /*This method login into using valid username and password*/

        GenericMethods.assignTestCaseId(2);
        GenericMethods.validAccountLoginAndNavigateToHome();

    }

    @AfterMethod(alwaysRun = true)
    void teardown()
    {
        Global_Utilities.webDriver.close();
    }

}
