package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.IOException;

public class WelcomePageTest extends BaseClass {

    WelcomePage welcomePageObj;

    @BeforeMethod(alwaysRun = true)
    void setUp() throws IOException {
        /*This method loads the url and login details from property file*/

        loadProperties();
        OpenBrowserAndNavigateToNeuroVentis(Global_Utilities.properties.getProperty("browser"));
    }
    @Test
    void validateTheExistingAccount() throws InterruptedException {
        /*This method clicks on existing account to login and validates login*/

        GenericMethods.assignTestCaseId(1);
        welcomePageObj= new WelcomePage();
        welcomePageObj.selectingExistingAccount();


    }

    @AfterMethod(alwaysRun = true)
    void teardown()
    {
        Global_Utilities.webDriver.close();
    }

}
