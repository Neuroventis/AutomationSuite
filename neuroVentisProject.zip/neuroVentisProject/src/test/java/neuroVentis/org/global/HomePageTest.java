package neuroVentis.org.global;

import neuroVentis.org.base.BaseClass;
import neuroVentis.org.utilities.Global_Utilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.io.IOException;

@Listeners(neuroVentis.org.utilities.listener_Utilities.ITListener.class)

public class HomePageTest extends BaseClass {


    HomePage homePageObj;

    @BeforeMethod(alwaysRun = true)
    void setUp() throws IOException{
        /*This method loads the url and login details from property file*/

        loadProperties();
        OpenBrowserAndNavigateToNeuroVentis(Global_Utilities.properties.getProperty("browser"));
        GenericMethods.validAccountLoginAndNavigateToHome();

    }

    @Test
    void validateAddFunctionality()  {
        /*This method validates click on Add and then click on Seizure*/
        GenericMethods.assignTestCaseId(3);

        homePageObj= new HomePage();
        homePageObj.addFunctionality();
    }

    @AfterMethod(alwaysRun = true)
    void teardown()
    {
        Global_Utilities.webDriver.close();
    }
}
